# Stock_Prediction

![alt text](https://github.com/anmolkhullar24/Stock_Prediction/blob/main/Sample%20Images%20GUI/front1.PNG)
![alt text](https://github.com/anmolkhullar24/Stock_Prediction/blob/main/Sample%20Images%20GUI/front2.PNG)
![alt text](https://github.com/anmolkhullar24/Stock_Prediction/blob/main/Sample%20Images%20GUI/front3.PNG)

python version - 3.6.8
